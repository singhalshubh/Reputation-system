from django.apps import AppConfig


class ReputationConfig(AppConfig):
    name = 'voting'
